#include <ncurses.h>
#include <curses.h>
#include <iostream>  
#include <iomanip>
#include <chrono>
#include <ctime>
#include "datetime.h"
#include "calendar.h"
#include "util.h"
#include "window.h"
using namespace std;

const char* months[] = {
    "January", "February", "March", "April",
    "May", "June", "July", "August",
    "September", "October", "November", "December"
};


int main() {
    int numRows, numCols;
    getmaxyx(stdscr, numRows, numCols); 
    Window win(numRows, numCols);

    Datetime localTime = getCurrentDateTime();
    win.getInput();

// Polymorphism
    Calendar * cal = nullptr;
    cal = new WeeklyCalendar();
    cal->print();

    delete cal;

    endwin();
    return 0;
}   
// Years -> monthly -> day 
//       -> monthly -> day
//       -> monthly -> day 